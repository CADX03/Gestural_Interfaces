Ripped by Hell Inspector under the submitter name "Hawkodile"
https://www.vg-resource.com/user-39500.html

Ripped with Random Talking Bush's 3DS Max Plugin.

Credit is appreciated but not needed.

Thank you and Have a great day! Have fun using this model.